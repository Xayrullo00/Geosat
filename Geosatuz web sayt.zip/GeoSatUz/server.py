#!/usr/bin/env python3
"""
GeoSatUz Proxy Server
- HTML fayllarni beradi
- Sentinel Hub CORS muammosini hal qiladi
- Anthropic API ni proxy qiladi
Ishlatish: python server.py
"""
import http.server
import socketserver
import urllib.request
import urllib.error
import json
import os

PORT = 8080

class ProxyHandler(http.server.SimpleHTTPRequestHandler):

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()

    def send_cors_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')

    def end_headers(self):
        self.send_cors_headers()
        super().end_headers()

    def do_POST(self):
        # /proxy/sentinel  →  Sentinel Hub API
        # /proxy/anthropic →  Anthropic API
        if self.path.startswith('/proxy/'):
            self.handle_proxy()
        else:
            self.send_error(404)

    def handle_proxy(self):
        length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(length) if length else b''

        if self.path == '/proxy/sentinel-token':
            target = 'https://services.sentinel-hub.com/auth/realms/main/protocol/openid-connect/token'
            req = urllib.request.Request(target, data=body,
                headers={'Content-Type': 'application/x-www-form-urlencoded'})

        elif self.path == '/proxy/sentinel-process':
            target = 'https://services.sentinel-hub.com/api/v1/process'
            auth = self.headers.get('X-Auth-Token', '')
            content_type = self.headers.get('Content-Type', 'application/json')
            req = urllib.request.Request(target, data=body,
                headers={'Authorization': 'Bearer ' + auth, 'Content-Type': content_type})

        elif self.path == '/proxy/anthropic':
            target = 'https://api.anthropic.com/v1/messages'
            api_key = self.headers.get('X-Api-Key', '')
            req = urllib.request.Request(target, data=body, headers={
                'Content-Type': 'application/json',
                'x-api-key': api_key,
                'anthropic-version': '2023-06-01'
            })
        else:
            self.send_error(404)
            return

        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                resp_body = resp.read()
                content_type = resp.headers.get('Content-Type', 'application/json')
                self.send_response(200)
                self.send_header('Content-Type', content_type)
                self.send_header('Content-Length', str(len(resp_body)))
                self.end_headers()
                self.wfile.write(resp_body)
        except urllib.error.HTTPError as e:
            err_body = e.read()
            self.send_response(e.code)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(err_body)
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'error': str(e)}).encode())

    def log_message(self, format, *args):
        msg = format % args
        status = args[1] if len(args) > 1 else ''
        color = '\033[92m' if str(status).startswith('2') else '\033[91m' if str(status).startswith(('4','5')) else '\033[93m'
        print(f"{color}[{self.address_string()}] {msg}\033[0m")

os.chdir(os.path.dirname(os.path.abspath(__file__)))

print("""
\033[92m╔══════════════════════════════════════╗
║       GeoSatUz Proxy Server          ║
╠══════════════════════════════════════╣
║  Manzil: http://localhost:8080       ║
╚══════════════════════════════════════╝\033[0m

\033[96mBrauzerda oching:\033[0m
  http://localhost:8080/agroai_v2.html

\033[93mTo'xtatish uchun: Ctrl+C\033[0m
""")

with socketserver.TCPServer(("", PORT), ProxyHandler) as httpd:
    httpd.serve_forever()
